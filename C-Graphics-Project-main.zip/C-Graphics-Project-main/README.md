# C-Graphics-Project
Here you can find the c++ Graphics project code......  

If you want to run this code you must to add graphics.h header file in your codeblock's IDE...

How to add graphics.h hedar file: [SEE_Videos](https://youtu.be/c7mJ0Qh9Dpk)

if you are satisfied, please give me star. 

------------------------------------------------------------------------------------------------------------

Project 1: Analog clock: [source code](https://github.com/me-badsha/C-Graphics-Project/blob/main/All%20Graphics%20Project%20Code/Analog%20clock.cpp)

    Picture is Loding.......

Project 2:In this time we can see many big building so that is a simple building structure: [Source_code](https://github.com/me-badsha/C-Graphics-Project/blob/main/All%20Graphics%20Project%20Code/Building.cpp)

    Picture is Loding.......

Project 3: Drawing a curcle: [Source Code here](https://github.com/me-badsha/C-Graphics-Project/blob/main/All%20Graphics%20Project%20Code/Draw%20a%20circle.cpp)

    Picture is Loding.......

Project 4: Flying our national flag: [Source Code here](https://github.com/me-badsha/C-Graphics-Project/blob/main/All%20Graphics%20Project%20Code/Flying%20the%20flag.cpp)

    Picture is Loding.......

Project 5: Hey hey! HAPPY NEW YEAR 😃: [Source Code here](https://github.com/me-badsha/C-Graphics-Project/blob/main/All%20Graphics%20Project%20Code/Happy_New_Year.cpp)

    Picture is Loding.......

Project 6: Moving Car in rain wow!: [Source Code here](https://github.com/me-badsha/C-Graphics-Project/blob/main/All%20Graphics%20Project%20Code/Moving%20Car%20in%20rain.cpp)

    Picture is Loding.......

Project 7: Moving cycle wow!: [Source Code here](https://github.com/me-badsha/C-Graphics-Project/blob/main/All%20Graphics%20Project%20Code/Moving%20Cycle.cpp)

    Picture is Loding.......

Project 8: Talking with friends!: [Source Code here](https://github.com/me-badsha/C-Graphics-Project/blob/main/All%20Graphics%20Project%20Code/Talking%20friend.cpp)

    Picture is Loding.......

Project 9: Traffic_light system: [Source Code here](https://github.com/me-badsha/C-Graphics-Project/blob/main/All%20Graphics%20Project%20Code/Traffic_light.cpp)

    Picture is Loding.......

Project 10: Small Uttara_City : [Source Code here](https://github.com/me-badsha/C-Graphics-Project/blob/main/All%20Graphics%20Project%20Code/Uttara_City.cpp)

    Picture is Loding.......

Project 11: Village-Rainbow wow! : [Source Code here](https://github.com/me-badsha/C-Graphics-Project/blob/main/All%20Graphics%20Project%20Code/Village-Rainbow.cpp)

    Picture is Loding.......

Project 12: Walking a single man like me!😁😁 : [Source Code here](https://github.com/me-badsha/C-Graphics-Project/blob/main/All%20Graphics%20Project%20Code/Walking%20man.cpp)

    Picture is Loding.......

Project 13: Fish aquarium : [Source Code here](https://github.com/me-badsha/C-Graphics-Project/blob/main/All%20Graphics%20Project%20Code/fish%20aquarium.cpp)

    Picture is Loding.......

Project 14: Flying Rocket: [Source Code here](https://github.com/me-badsha/C-Graphics-Project/blob/main/All%20Graphics%20Project%20Code/flying%20Rocket.cpp)

    Picture is Loding.......

Project 15: Nature is very beautiful: [Source Code here](https://github.com/me-badsha/C-Graphics-Project/blob/main/All%20Graphics%20Project%20Code/nature%20beauty.cpp)

    Picture is Loding.......

Project 16: twoinOne: [Source Code here](https://github.com/me-badsha/C-Graphics-Project/blob/main/All%20Graphics%20Project%20Code/twoinOne.cpp)

    Picture is Loding.......


